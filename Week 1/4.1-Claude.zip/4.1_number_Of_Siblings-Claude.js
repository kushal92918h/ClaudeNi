numSiblings = window.prompt("How many siblings do you have?");

if (parseInt(numSiblings) === 1) {
  console.log("1 sibling!");
} else if (parseInt(numSiblings) > 1) {
  console.log("More than 1 sibling");
} else {
    console.log("No siblings");
}
